public interface Colorable {
  public void howToColor();
}
