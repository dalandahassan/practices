/*
  Write a program that displays Welcome to Java five times.
*/

public class E1_02 {
  public static void main(String[] args) {
    for (int i = 0; i < 5; i++) {
      System.out.println("Welcome to Java");
    }
  }
}
