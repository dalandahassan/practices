public class HexFormatException extends Exception {
  public HexFormatException(String message) {
    super(message);
  }
}
