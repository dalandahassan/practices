public class BinaryFormatException extends Exception {
  public BinaryFormatException(String message) {
    super(message);
  }
}
