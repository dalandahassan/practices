public class Location {
  public int row;
  public int column;
  public double maxValue;
}
